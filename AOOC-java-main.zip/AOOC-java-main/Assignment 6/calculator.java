package ExceptionHandlingDemo;
import java.util.*;
public class calculator
{
	public void division(int a,int b){
		System.out.println("Division: "+(a/b));
	}
}

