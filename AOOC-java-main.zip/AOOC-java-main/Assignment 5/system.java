import LibraryManagement.Books;
import LibraryManagement.member;
import java.util.*;
class system
{
	public static void main(String args[]){
		Books b = new Books();
		member m = new member();
		m.setm();
		b.set();
		System.out.println();
		System.out.println("***Library Receipt***");
		m.getm();
		b.get();
		System.out.println("Book pursued successfully");
		System.out.println("**Thank You**");
	}
}