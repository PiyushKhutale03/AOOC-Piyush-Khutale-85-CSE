package MathOperations;
import java.lang.Math;
import java.util.*;
public class roundop
{
	public void Round(float a){
		System.out.println("Round: "+Math.round(a));
	}
}