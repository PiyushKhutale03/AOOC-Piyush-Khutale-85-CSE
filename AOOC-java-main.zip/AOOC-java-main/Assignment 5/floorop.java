package MathOperations;
import java.lang.Math;
import java.util.*;
public class floorop
{
	public void Floor(float a){
		System.out.println("Floor: "+Math.floor(a));
	}
}