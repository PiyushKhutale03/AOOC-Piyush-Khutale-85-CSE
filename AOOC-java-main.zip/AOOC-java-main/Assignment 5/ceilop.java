package MathOperations;
import java.lang.Math;
import java.util.*;
public class ceilop
{
	public void Ceil(float a){
		System.out.println("Ceil: "+Math.ceil(a));
	}
}